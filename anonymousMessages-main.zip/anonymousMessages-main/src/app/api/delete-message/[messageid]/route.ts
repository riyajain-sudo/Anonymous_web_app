import { getServerSession } from "next-auth";
import { authOptions } from "../../auth/[...nextauth]/options";
import dbConnect from "@/lib/dbConnect";
import UserModel from "@/model/User";
import {User} from "next-auth";
import { Message } from '@/model/User';
import { NextRequest } from 'next/server';


export async function DELETE(
    request: Request,
    {params}: {params: {messageid: string}}
){
    const messageId = params.messageid
    await dbConnect()
    const session = await getServerSession(authOptions)
        const _user: User = session?.user
    
    if(!session || !session.user){
        return Response.json(
            {
                success: false,
                message: "User not logged in!"
            },
            {status: 401}
        )
    }
    try {
        const updatedResult = await UserModel.updateOne(
            {_id: _user},
            {$pull: {messages: {_id: messageId}}}
        )
        if(updatedResult.modifiedCount == 0){
            return Response.json({
                success: false,
                message: 'Message not found or already deleted'
            },
            {status: 404}
        )
    }
     return Response.json({
                success: true,
                message: 'Message deleted succesfully!'
            },
            {status: 200}
        )

    } catch (error) {
        return Response.json({
            success: false,
            message: 'Error deleting the message'
        },{status: 500}
    )
    }
}
    