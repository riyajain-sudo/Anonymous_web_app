import dbConnect from "@/lib/dbConnect";
import UserModel from "@/model/User";
import { messageSchema } from "@/schemas/messageSchema";
import { Message } from "@/model/User";


export async function POST(request: Request) {
    await dbConnect()

    const {username, content} = await request.json()

    try {
        const user = await UserModel.findOne({username})
        if(!user){
            return Response.json(
                {
                    success: false,
                    message: "User not found!"
                },
                {status: 401}
            )
        }

        //is user accepting the messages

        console.log("Accepting messages?", user.isAcceptingMessage)
        if (!user.isAcceptingMessage) {
        return Response.json({ success: false, message: "User is not accepting messages" }, { status: 403 })
        }

        if(!user.isAcceptingMessage){
            return Response.json(
                {
                    success: false,
                    message: "User is not accepting messages"
                },
                {status: 403}
            )
        }

        const newMessage = {content, createdAt: new Date()}
        user.messages.push(newMessage as Message)
        await user.save()

        return Response.json(
            {
                success: true,
                message: "Message sent!"
            },
            {status: 200}
        )

    } catch (error) {
        console.log("error sending messages", error)
        return Response.json(
            {
                success: false,
                message: "Error sending messages"
            },
            {status: 500}
        )
    }
}