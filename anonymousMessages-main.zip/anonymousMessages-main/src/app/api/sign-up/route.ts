import dbConnect from '@/lib/dbConnect';
import UserModel from '@/model/User';
import bcrypt from 'bcryptjs';
import { sendVerificationEmail } from '@/helpers/sendverificationEmail';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(request: Request) {
  await dbConnect();

  try {
    const { username, email, password } = await request.json();

    // Always generate a verification code
    const verifyCode = Math.floor(100000 + Math.random() * 900000).toString();

    // Check if username is already taken
    const existingVerifiedUserByUsername = await UserModel.findOne({
      username,
      isVerified: true,
    });
    if (existingVerifiedUserByUsername) {
      return Response.json(
        { success: false, message: 'Username is already taken' },
        { status: 400 }
      );
    }

    // Check if email exists
    const existingUserByEmail = await UserModel.findOne({ email });

    if (existingUserByEmail) {
      if (existingUserByEmail.isVerified) {
        return Response.json(
          { success: false, message: 'User already exists with this email' },
          { status: 400 }
        );
      } else {
        const hashedPassword = await bcrypt.hash(password, 10);
        existingUserByEmail.password = hashedPassword;
        existingUserByEmail.verifyCode = verifyCode;
        existingUserByEmail.verifyCodeExpiry = new Date(Date.now() + 3600000); // 1 hour
        await existingUserByEmail.save();
      }
    } else {
      const hashedPassword = await bcrypt.hash(password, 10);
      const expiryDate = new Date(Date.now() + 3600000); // 1 hour

      const newUser = new UserModel({
        username,
        email,
        password: hashedPassword,
        verifyCode,
        verifyCodeExpiry: expiryDate,
        isVerified: false,
        isAcceptingMessages: true,
        messages: [],
      });

      await newUser.save();
    }

     try {
      await resend.emails.send({
        from: 'True Feedback <onboarding@resend.dev>',
        to: email,
        subject: 'Verify your account',
        html: `
          <h2>Hello ${username},</h2>
          <p>Thank you for signing up on <b>True Feedback</b>!</p>
          <p>Your verification code is:</p>
          <h3 style="color:#4f46e5;">${verifyCode}</h3>
          <p>This code will expire in 1 hour.</p>
        `,
      });
    } catch (err: any) {
      console.error('Error sending verification email:', err);
      return Response.json(
        {
          success: false,
          message: 'Failed to send verification email. Please try again later.',
        },
        { status: 500 }
      );
    }

    // // Send verification email safely
    let emailResponse;
    try {
      emailResponse = await sendVerificationEmail(email, username, verifyCode);
    } catch (err: any) {
      console.error('Error sending verification email:', err);
      return Response.json(
        {
          success: false,
          message: 'Failed to send verification email. Please try again later.',
        },
        { status: 500 }
      );
    }

    if (!emailResponse.success) {
      return Response.json(
        {
          success: false,
          message: emailResponse.message || 'Failed to send verification email',
        },
        { status: 500 }
      );
    }

    return Response.json(
      {
        success: true,
        message: 'User registered successfully. Please verify your account.',
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('Error registering user:', error.message, error.stack);
    return Response.json(
      {
        success: false,
        message: error.message || 'Error registering user',
      },
      { status: 500 }
    );
  }
}
